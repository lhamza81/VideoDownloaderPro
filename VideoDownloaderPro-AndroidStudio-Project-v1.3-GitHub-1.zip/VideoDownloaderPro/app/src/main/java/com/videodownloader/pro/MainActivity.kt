package com.videodownloader.pro

import android.app.AlertDialog
import android.Manifest
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.content.pm.PackageManager
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import android.view.Gravity
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONTokener
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val bg = 0xFF101923.toInt()
    private val panel = 0xFF1B2935.toInt()
    private val accent = 0xFF35B7A5.toInt()
    private lateinit var content: FrameLayout
    private lateinit var address: EditText
    private var web: WebView? = null
    private var currentTab = "Home"
    private val mediaPermissionRequest = 501

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildShell()
        showHome()
    }

    private fun buildShell() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(20, 18, 20, 14); setBackgroundColor(bg)
        }
        header.addView(TextView(this).apply {
            text = "▶  VIDEO DOWNLOADER"; textSize = 18f; setTextColor(-1)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(TextView(this).apply {
            text = "⋮"; textSize = 28f; setTextColor(-1)
            setOnClickListener { currentTab = "Settings"; showSettings() }
        })
        root.addView(header)
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setBackgroundColor(0xFF17232E.toInt()); setPadding(4, 8, 4, 8)
        }
        listOf("Home", "Browser", "Downloads", "Library").forEach { tab ->
            nav.addView(TextView(this).apply {
                text = when (tab) { "Home" -> "⌂\nHome"; "Browser" -> "◎\nBrowser"; "Downloads" -> "↓\nDownloads"; else -> "▣\nLibrary" }
                gravity = Gravity.CENTER; textSize = 12f
                setTextColor(if (tab == currentTab) accent else 0xFFB8C5CE.toInt())
                setPadding(2, 4, 2, 4)
                setOnClickListener {
                    currentTab = tab
                    when (tab) {
                        "Home" -> showHome()
                        "Browser" -> showBrowser("https://www.google.com")
                        "Downloads" -> showDownloads()
                        else -> showLibrary()
                    }
                }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)
    }

    private fun page(title: String, subtitle: String? = null): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 12, 18, 18); setBackgroundColor(bg) }
        box.addView(TextView(this).apply {
            text = title; textSize = 24f; setTextColor(-1); typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        if (subtitle != null) box.addView(TextView(this).apply {
            text = subtitle; textSize = 13f; setTextColor(0xFF9EAFBC.toInt()); setPadding(0, 5, 0, 12)
        })
        return box
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16); setBackgroundColor(panel)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 10, 0, 10) }
    }

    private fun action(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label; isAllCaps = false; setTextColor(0xFF062B2A.toInt())
        backgroundTintList = android.content.res.ColorStateList.valueOf(accent)
        setOnClickListener { onClick() }
    }

    private fun smallAction(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = 12f; gravity = Gravity.CENTER; setTextColor(-1)
        setPadding(10, 10, 10, 10); setOnClickListener { onClick() }
    }

    private fun showHome() {
        web?.destroy(); web = null
        val p = page("Download videos", "Browse supported sites or paste a direct media link")
        val c = card()
        c.addView(TextView(this).apply { text = "Video URL"; setTextColor(-1); textSize = 15f })
        address = EditText(this).apply {
            hint = "https://example.com/video.mp4"; setHintTextColor(0xFF81919D.toInt())
            setTextColor(-1); setSingleLine(true); setPadding(12, 8, 12, 8)
            setBackgroundColor(0xFF263846.toInt()); inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        c.addView(address, LinearLayout.LayoutParams(-1, 52))
        c.addView(action("Download", ::downloadEnteredUrl), LinearLayout.LayoutParams(-1, -2))
        p.addView(c)
        val quick = card()
        quick.addView(TextView(this).apply {
            text = "Quick access"; textSize = 17f; typeface = android.graphics.Typeface.DEFAULT_BOLD; setTextColor(-1)
        })
        quick.addView(action("Open browser", { currentTab = "Browser"; showBrowser("https://www.google.com") }))
        quick.addView(action("My downloads", { currentTab = "Downloads"; showDownloads() }))
        quick.addView(action("Play local videos", { currentTab = "Library"; showLibrary() }))
        p.addView(quick)
        p.addView(TextView(this).apply {
            text = "Find video scans HTML5 video elements exposed by the page. Direct files can be downloaded; accessible HLS/DASH streams can be played. DRM and website restrictions are not bypassed."
            textSize = 12f; setTextColor(0xFF9EAFBC.toInt()); setPadding(4, 12, 4, 4)
        })
        content.removeAllViews(); content.addView(ScrollView(this).apply { addView(p) })
    }

    private fun showBrowser(start: String) {
        web?.destroy()
        val shell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(8, 8, 8, 4) }
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = 0; visibility = android.view.View.GONE
        }
        shell.addView(progress, LinearLayout.LayoutParams(-1, 4))
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val url = EditText(this).apply {
            setSingleLine(true); textSize = 12f; hint = "Enter website address"; setText(start)
            setTextColor(-1); setHintTextColor(0xFF81919D.toInt()); setBackgroundColor(panel)
            setPadding(10, 4, 10, 4); inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        bar.addView(url, LinearLayout.LayoutParams(0, 48, 1f))
        bar.addView(smallAction("Go") { loadAddress(url.text.toString()) })
        shell.addView(bar)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        controls.addView(smallAction("‹") { web?.goBack() })
        controls.addView(smallAction("›") { web?.goForward() })
        controls.addView(smallAction("↻") { web?.reload() })
        controls.addView(smallAction("Find video") { findPageVideos() })
        shell.addView(controls)

        val browser = WebView(this).apply {
            settings.javaScriptEnabled = true; settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = true; settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView, pageUrl: String, favicon: android.graphics.Bitmap?) {
                    progress.visibility = android.view.View.VISIBLE
                    progress.progress = 5
                }
                override fun onPageFinished(view: WebView, pageUrl: String) {
                    if (!url.hasFocus()) url.setText(pageUrl)
                    progress.progress = 100
                    progress.postDelayed({ progress.visibility = android.view.View.GONE }, 250)
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView, newProgress: Int) {
                    progress.progress = newProgress
                    if (newProgress >= 100) progress.visibility = android.view.View.GONE
                    else progress.visibility = android.view.View.VISIBLE
                }
            }
            setDownloadListener { link, agent, disposition, mime, _ ->
                enqueueDownload(link, URLUtil.guessFileName(link, disposition, mime), mime ?: "application/octet-stream", agent)
            }
        }
        CookieManager.getInstance().setAcceptCookie(true)
        shell.addView(browser, LinearLayout.LayoutParams(-1, 0, 1f))
        web = browser
        content.removeAllViews(); content.addView(shell)
        browser.loadUrl(start)
    }

    private fun loadAddress(raw: String) {
        val trimmed = raw.trim()
        if (trimmed.isBlank()) return
        val value = if (trimmed.startsWith("http://", true) || trimmed.startsWith("https://", true)) trimmed else "https://$trimmed"
        val uri = Uri.parse(value)
        if (uri.scheme !in listOf("http", "https") || uri.host.isNullOrBlank()) {
            Toast.makeText(this, "Enter a valid website address", Toast.LENGTH_SHORT).show(); return
        }
        web?.loadUrl(value)
    }

    // Reads only media URLs explicitly exposed by HTML5 video/source elements in the current page DOM.
    private fun findPageVideos() {
        val script = """
            (function(){
              const found=[];
              const add=(raw)=>{try{const u=new URL(raw,document.baseURI);if((u.protocol==='https:'||u.protocol==='http:')&&!found.includes(u.href))found.push(u.href);}catch(e){}};
              document.querySelectorAll('video').forEach(v=>{if(v.currentSrc)add(v.currentSrc);if(v.src)add(v.src);v.querySelectorAll('source').forEach(s=>add(s.src));});
              document.querySelectorAll('source').forEach(s=>add(s.src));
              return JSON.stringify(found.slice(0,25));
            })();
        """.trimIndent()
        web?.evaluateJavascript(script) { raw ->
            try {
                val decoded = JSONTokener(raw).nextValue() as? String ?: "[]"
                val values = JSONArray(decoded)
                val links = (0 until values.length()).map { values.optString(it) }
                    .filter { it.startsWith("http://") || it.startsWith("https://") }
                if (links.isEmpty()) {
                    Toast.makeText(this, "No exposed HTML5 video URL found", Toast.LENGTH_LONG).show()
                } else {
                    AlertDialog.Builder(this).setTitle("Detected media (${links.size})")
                        .setItems(links.toTypedArray()) { _, which -> handleDetectedMedia(links[which]) }
                        .setNegativeButton("Close", null).show()
                }
            } catch (_: Exception) {
                Toast.makeText(this, "Could not read media links", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun handleDetectedMedia(link: String) {
        val path = Uri.parse(link).lastPathSegment?.lowercase(Locale.ROOT).orEmpty()
        if (path.endsWith(".m3u8") || path.endsWith(".mpd")) {
            AlertDialog.Builder(this).setTitle("Streaming media")
                .setMessage("This is an HLS/DASH stream. It can be played if accessible, but this version does not save segmented streams for offline use.")
                .setPositiveButton("Play") { _, _ -> startActivity(Intent(this, PlayerActivity::class.java).setData(Uri.parse(link))) }
                .setNegativeButton("Cancel", null).show()
        } else {
            enqueueDownload(link, URLUtil.guessFileName(link, null, null), "application/octet-stream", null)
        }
    }

    private fun downloadEnteredUrl() {
        val raw = address.text.toString().trim()
        if (raw.isBlank()) { address.error = "Enter a video URL"; return }
        val uri = Uri.parse(raw)
        if (uri.scheme !in listOf("http", "https") || uri.host.isNullOrBlank()) {
            address.error = "Enter a valid http(s) URL"; return
        }
        val path = uri.lastPathSegment?.lowercase(Locale.ROOT).orEmpty()
        if (path.endsWith(".m3u8") || path.endsWith(".mpd")) handleDetectedMedia(raw)
        else enqueueDownload(raw, URLUtil.guessFileName(raw, null, null), "application/octet-stream", null)
    }

    private fun enqueueDownload(url: String, suggestedName: String, mime: String, userAgent: String?) {
        try {
            val parsed = Uri.parse(url)
            if (parsed.scheme !in listOf("http", "https") || parsed.host.isNullOrBlank()) {
                Toast.makeText(this, "Only HTTP and HTTPS links are supported", Toast.LENGTH_SHORT).show(); return
            }
            val safeName = suggestedName.substringAfterLast('/').substringAfterLast('\\')
                .replace(Regex("[\\\\/:*?\"<>|]"), "_").take(120)
                .ifBlank { "video_${System.currentTimeMillis()}" }
            val request = DownloadManager.Request(parsed).apply {
                setTitle(safeName); setDescription("Video Downloader Pro")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "VideoDownloaderPro/$safeName")
                setAllowedOverMetered(true); setAllowedOverRoaming(false)
                if (!userAgent.isNullOrBlank()) addRequestHeader("User-Agent", userAgent)
                CookieManager.getInstance().getCookie(url)?.takeIf { it.isNotBlank() }?.let { addRequestHeader("Cookie", it) }
                if (mime.isNotBlank()) setMimeType(mime)
            }
            val id = (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
            getSharedPreferences("downloads", MODE_PRIVATE).edit().putString(id.toString(), safeName).apply()
            Toast.makeText(this, "Download started: $safeName", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start download: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showDownloads() {
        val p = page("Downloads", "Transfers managed by Android Download Manager")
        val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val cursor = manager.query(DownloadManager.Query())
        if (cursor == null || cursor.count == 0) p.addView(emptyLabel("No downloads yet"))
        else cursor.use { cur ->
            val idCol = cur.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)
            val titleCol = cur.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)
            val statusCol = cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)
            val totalCol = cur.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
            val doneCol = cur.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
            while (cur.moveToNext()) {
                val id = cur.getLong(idCol); val title = cur.getString(titleCol) ?: "Download"
                val status = cur.getInt(statusCol); val total = cur.getLong(totalCol); val done = cur.getLong(doneCol)
                val state = when (status) {
                    DownloadManager.STATUS_SUCCESSFUL -> "Completed"
                    DownloadManager.STATUS_FAILED -> "Failed"
                    DownloadManager.STATUS_PAUSED -> "Paused"
                    DownloadManager.STATUS_PENDING -> "Waiting"
                    DownloadManager.STATUS_RUNNING -> "Downloading"
                    else -> "Unknown"
                }
                val c = card()
                c.addView(TextView(this).apply { text = title; textSize = 15f; setTextColor(-1) })
                c.addView(TextView(this).apply {
                    text = state + if (total > 0) " • ${done * 100 / total}%" else ""
                    setTextColor(0xFFB8C5CE.toInt())
                })
                if (status == DownloadManager.STATUS_RUNNING || status == DownloadManager.STATUS_PENDING) {
                    c.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                        max = 100; progress = if (total > 0) (done * 100 / total).toInt() else 0
                    }, LinearLayout.LayoutParams(-1, 8))
                }
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                if (status == DownloadManager.STATUS_SUCCESSFUL) {
                    val fileUri = manager.getUriForDownloadedFile(id)
                    if (fileUri != null) {
                        c.addView(thumbnailView(fileUri), LinearLayout.LayoutParams(132, 78))
                        row.addView(smallAction("Play / Open") {
                            startActivity(Intent(this@MainActivity, PlayerActivity::class.java).setData(fileUri))
                        })
                    }
                }
                row.addView(smallAction("Remove / Cancel") { manager.remove(id); showDownloads() })
                c.addView(row); p.addView(c)
            }
        }
        p.addView(action("Refresh", ::showDownloads))
        content.removeAllViews(); content.addView(ScrollView(this).apply { addView(p) })
    }

    private fun showLibrary() {
        val permission = if (android.os.Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_VIDEO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
            AlertDialog.Builder(this)
                .setTitle("Media library access")
                .setMessage("Allow access to videos on this device so Video Downloader Pro can display and play your local video files.")
                .setPositiveButton("Continue") { _, _ ->
                    ActivityCompat.requestPermissions(this, arrayOf(permission), mediaPermissionRequest)
                }
                .setNegativeButton("Not now", null)
                .show()
            return
        }
        val p = page("Video library", "Videos indexed on this device")
        val projection = arrayOf(android.provider.MediaStore.Video.Media._ID, android.provider.MediaStore.Video.Media.DISPLAY_NAME)
        val videos = ArrayList<Pair<String, Uri>>()
        contentResolver.query(android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, null, null,
            "${android.provider.MediaStore.Video.Media.DATE_ADDED} DESC")?.use { cur ->
            val idCol = cur.getColumnIndexOrThrow(android.provider.MediaStore.Video.Media._ID)
            val nameCol = cur.getColumnIndexOrThrow(android.provider.MediaStore.Video.Media.DISPLAY_NAME)
            while (cur.moveToNext()) {
                val id = cur.getLong(idCol); val name = cur.getString(nameCol) ?: "Video"
                videos.add(name to Uri.withAppendedPath(android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id.toString()))
            }
        }
        if (videos.isEmpty()) p.addView(emptyLabel("No local videos found. Downloaded videos may take a moment to appear after Android indexes them."))
        videos.forEach { (name, uri) ->
            val c = card()
            c.orientation = LinearLayout.HORIZONTAL
            c.gravity = Gravity.CENTER_VERTICAL
            c.addView(thumbnailView(uri), LinearLayout.LayoutParams(124, 78))
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 0, 0, 0) }
            details.addView(TextView(this).apply { text = name; textSize = 14f; setTextColor(-1); maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
            details.addView(smallAction("▶  Play") { startActivity(Intent(this@MainActivity, PlayerActivity::class.java).setData(uri)) })
            c.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            p.addView(c)
        }
        p.addView(action("Refresh library", ::showLibrary))
        content.removeAllViews(); content.addView(ScrollView(this).apply { addView(p) })
    }


    private fun thumbnailView(uri: Uri): ImageView {
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFF263846.toInt())
            setImageResource(android.R.drawable.ic_media_play)
            contentDescription = "Video thumbnail"
        }
        Thread {
            val bitmap = try {
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    contentResolver.loadThumbnail(uri, android.util.Size(320, 180), null)
                } else {
                    val retriever = android.media.MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(this, uri)
                        retriever.getFrameAtTime(1_000_000, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    } finally { retriever.release() }
                }
            } catch (_: Exception) { null }
            if (bitmap != null && !isFinishing) runOnUiThread { image.setImageBitmap(bitmap) }
        }.start()
        return image
    }

    private fun showSettings() {
        val p = page("Settings", "Video Downloader Pro")
        p.addView(card().apply {
            addView(TextView(this@MainActivity).apply {
                text = "Downloads are saved in Downloads/VideoDownloaderPro. Browser downloads use Android Download Manager. The player supports common media files and accessible HLS/DASH streams."
                setTextColor(-1); textSize = 14f
            })
            addView(TextView(this@MainActivity).apply { text = "Version 1.2.0"; setTextColor(0xFF9EAFBC.toInt()); setPadding(0, 12, 0, 0) })
        })
        content.removeAllViews(); content.addView(p)
    }

    private fun emptyLabel(value: String) = TextView(this).apply {
        text = value; textSize = 14f; setTextColor(0xFF9EAFBC.toInt()); setPadding(8, 24, 8, 24)
    }

    @Deprecated("Deprecated in Android API")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == mediaPermissionRequest && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            showLibrary()
        } else if (requestCode == mediaPermissionRequest) {
            Toast.makeText(this, "Video library permission was not granted", Toast.LENGTH_SHORT).show()
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (currentTab == "Browser" && web?.canGoBack() == true) web?.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        web?.stopLoading(); web?.destroy(); web = null
        super.onDestroy()
    }
}
