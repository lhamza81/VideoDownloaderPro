# Video Downloader Pro — Android

An original Android app inspired by the general workflow of the supplied All Video Downloader & Player 1.9.9 reference. It does not reuse that app's source code, branding, icons, or proprietary assets.

## Version 1.2.0 features
- Dark four-tab interface: Home, Browser, Downloads, Library.
- In-app WebView browser with back, forward, reload and address navigation.
- **Find video** scans HTML5 `<video>` and `<source>` elements for media URLs explicitly exposed by the current page.
- Direct HTTP(S) media downloads through Android DownloadManager.
- Browser user-agent and page cookies are passed to downloads initiated by WebView.
- Download status, transfer progress, refresh, remove/cancel, and open/play for completed items.
- Browser page-load progress indicator.
- Video thumbnail previews in the local library and completed-download list (generated on background threads).
- Player controls for ±10-second seeking, playback speeds from 0.5× to 2×, Fit/Fill/Zoom display modes, and immersive fullscreen.
- Local video discovery through MediaStore with runtime media-library permission.
- Media3 ExoPlayer playback with HLS and DASH playback modules included.

## Build APK automatically with GitHub Actions (recommended)

This repository includes `.github/workflows/android-apk.yml`. GitHub will build a debug APK for you in the cloud; you do not need to install Android Studio or the Android SDK on your own computer.

1. Sign in to [GitHub](https://github.com/) and create a **new empty repository** (for example, `VideoDownloaderPro`). Do not initialize it with a README or license.
2. Extract this project ZIP on your computer.
3. Upload the **contents** of the `VideoDownloaderPro` folder to the root of your GitHub repository. Make sure `.github/workflows/android-apk.yml` is included. On GitHub, use **Add file → Upload files**, drag the extracted files and folders, then **Commit changes**.
4. Open the repository's **Actions** tab. Select **Build Android APK** if needed, then open the run triggered by your commit.
5. Wait for the job to finish with a green check. Open that run and find **Artifacts** at the bottom; download `VideoDownloaderPro-debug-apk`.
6. Extract the downloaded artifact ZIP. It contains `app-debug.apk`. Transfer it to your Android phone and install it. If Android asks, allow installation from that source.

Every push to `main` or `master` and every pull request targeting those branches triggers a build. You can also run it manually from **Actions → Build Android APK → Run workflow**.

### Create a GitHub Release with the APK attached

After pushing the project, create and push a version tag from a terminal in the repository:

```bash
git tag v1.2.0
git push origin v1.2.0
```

The same workflow builds the APK and attaches `app-debug.apk` to the GitHub Release for that tag. A tag build is still a **debug-signed APK**, not a Play Store production release.

## Build locally (optional)

Requirements: JDK 17, Gradle 8.9, Android SDK Platform 35 and Build Tools 35.0.0.

```bash
gradle --no-daemon assembleDebug
```

The output is:
`app/build/outputs/apk/debug/app-debug.apk`

## App identity
- Application ID: `com.videodownloader.pro`
- Version: `1.2.0` (versionCode 3)
- Minimum Android: API 23 (Android 6.0)
- Target Android: API 35

## Boundaries and limitations
- The page scanner only sees media URLs exposed through the page's HTML DOM. It is not a universal website extractor.
- Direct downloadable files can be saved with Android DownloadManager.
- HLS (`.m3u8`) and DASH (`.mpd`) candidates can be played when accessible, but this version does **not** save segmented HLS/DASH streams for offline use.
- No DRM circumvention, paywall bypass, private-content extraction, or evasion of website restrictions.
- Android DownloadManager owns direct-file background transfer lifecycle and system notifications. App-level pause/resume controls are not implemented.
